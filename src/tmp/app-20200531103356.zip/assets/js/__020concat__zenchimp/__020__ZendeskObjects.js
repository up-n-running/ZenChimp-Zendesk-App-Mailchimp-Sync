/* global Function, __app */

/**
 *  * Constructor to create a new ZendeskOrganization
 * @param {Object} __app The Zendesk App That is being used to call this constructor 
 * @param {int} __id The Zendesk ID of organization
 * @param {string} name The Zendesk name of organization
 * @param {string} customer_type (value of organization's default customer_type field to assign to this user's org)
 * @returns {ZendeskOrganization} Instantiated Object
 */
    function ZendeskOrganization( app, id, name, customer_type )
    {
        this.__app = app;
        this.__id = id;
        this.name = name;
        this.__customer_type = customer_type;
        this.__extra_org_fields = [];

        for(var i = 0; i < app.__field_maps.organisation.length; i++) 
        {
            this.__extra_org_fields[ i ] = { __field_def: app.__field_maps.organisation[ i ], __value: null };
        }        
    }
    ZendeskOrganization.prototype.populateExtraFieldsFromOrganizationAPIData = function( APIOrgData )
    {
        for(var i = 0; i < this.__extra_org_fields.length; i++) 
        {
            this.__extra_org_fields[ i ].__value = APIOrgData.organization_fields[ this.__extra_org_fields[ i ].__field_def.zendesk_field ];
        }
    };
    ZendeskOrganization.prototype.populateExtraFieldsFromFrameworkOrgObject = function( frameworkOrgObject )
    {
        for(var i = 0; i < this.__extra_org_fields.length; i++) 
        {
            this.__extra_org_fields[ i ].__value = frameworkOrgObject.customField( this.__extra_org_fields[ i ].__field_def.zendesk_field );
        }
    };
    /**
     * inline clone function for user object - deep clones by calling organization.clone too
     * @returns {nm$_ZendeskObjects.ZendeskUser|ZendeskOrganization.prototype.clone.clonedOrganization|nm$_ZendeskObjects.ZendeskOrganization.prototype.clone.clonedOrganization}
     */
    ZendeskOrganization.prototype.clone = function()
    {
        var clonedOrganization = new ZendeskOrganization( this.__app, this.__id, this.name, this.__customer_type );
        //console.log( "cloning Org, this.name = '" + this.name + "', new ZendeskOrganization = ");
        //console.dir( clonedOrganization );
        for(var i = 0; i < this.__extra_org_fields.length; i++) 
        {
            clonedOrganization.__extra_org_fields[ i ] = { __field_def: this.__extra_org_fields[ i ].__field_def, __value: this.__extra_org_fields[ i ].__value };
        }
        //console.log( "finished cloning Org, clonedOrganization = ");
        //console.dir( clonedOrganization );
        return clonedOrganization;
    };


/**
 * Constructor to either create from scratch or clone a new ZendeskUser from: EITHER a Zendesk User API return data object OR an existing ZendeskUser object to clone
 * @param {Object} __app The Zendesk App That is being used to call this constructor 
 * @param {Object} userObjectToCopy the Zendesk User API return data object OR existing ZendeskUser object to clone
 * @returns {ZendeskUser} Instantiated Object with field mappings set up but organization subobject remains null to be populated as and when needed
 */
    function ZendeskUser( app, userObjectToCopy )
    {
        /* DebugOnlyCode - START */ 
        if( debug_mode ) 
        { 
            console.group( "new ZendeskUser (app, userObjectToCopy) constructor called" );
            console.log( "ARG1: app = %o", app );
            console.log( "ARG2: userObjectToCopy (of type '%s') = %o", typeof( userObjectToCopy ), userObjectToCopy );
        }
        /* DebugOnlyCode - END */ 
        
        if( typeof( userObjectToCopy ) === 'ZendeskUser' )
        {
            //WE ARE CLONING AN EXISTING ZendeskUser OBJECT
            
            /* DebugOnlyCode - START */ 
            if( debug_mode ) { console.log( "CLONING existing ZendeskUser"); }
            /* DebugOnlyCode - END */ 
            this.__app = userObjectToCopy.__app;
            this.__id = userObjectToCopy.__id;
            this.name = userObjectToCopy.name;
            this.__name_parts = null;
            this.email = userObjectToCopy.email;
            this.customer_type = userObjectToCopy.customer_type;
            this.__organization_id = userObjectToCopy.__organization_id;
            this.__orgObject = ( userObjectToCopy.__orgObject === null) ? null : userObjectToCopy.__orgObject.clone();
            this.__extra_user_fields = [];
            
            for(var i = 0; i < userObjectToCopy.__extra_user_fields.length; i++) 
            {
                this.__extra_user_fields[ i ] = { field_def: this.__extra_user_fields[ i ].field_def, value: this.__extra_user_fields[ i ].value };
            }
        }
        else
        {
            let userObjectFromDataAPI = userObjectToCopy;
            if( !userObjectFromDataAPI || !userObjectFromDataAPI.user )
            {
                throw new TypeError( "The Zendesk API used to get the user details returned no user information." );
            }

            if( typeof( userObjectFromDataAPI.user.user_fields.mailshot_customer_type ) === 'undefined' )
            {
                throw new ReferenceError( "The required Zendesk field with key mailshot_customer_type is missing. This should have been created during installation. Please reinstall or raise a bug using the link below" );
            }

            this.__app = app;
            this.__id = userObjectFromDataAPI.user.__id;
            this.name = userObjectFromDataAPI.user.name;
            this.__name_parts = null;
            this.email = userObjectFromDataAPI.user.email;
            this.customer_type = userObjectFromDataAPI.user.user_fields.mailshot_customer_type;
            this.__organization_id = ( typeof( userObjectFromDataAPI.user.organization_id ) !== 'undefined' && userObjectFromDataAPI.user.organization_id !== null ) ? userObjectFromDataAPI.user.organization_id : null; //being careful as sometimes users can be set to link through to more than one org depending on admin settings
            this.__orgObject = null;  //this will only be instantiated when needed, not now, even if there is an organization id
            this.__extra_user_fields = [];

            for(var i = 0; i < app.__field_maps.user.length; i++) 
            {
                this.__extra_user_fields[ i ] = { field_def: app.__field_maps.user[ i ], value: null };
            }

            /* DebugOnlyCode - START */ 
            if( debug_mode ) { console.log( "Completed part 1 of 2, basic user: this = %o", this); }
            /* DebugOnlyCode - END */ 

            //now set the optional extra user fields from returned API data
            this.populateExtraFieldsFromUserAPIData( userObjectFromDataAPI.user );
            
            /* DebugOnlyCode - START */ 
            if( debug_mode ) {  console.log( "Completed part 2 of 2, after populateExtraFieldsFromUserAPIData(...)"); }
            /* DebugOnlyCode - END */
        }
        
        /* DebugOnlyCode - START */ 
        if( debug_mode ) 
        { 
            console.log( "Finished constructor. this = %o", this);
            console.groupEnd();
        }
        /* DebugOnlyCode - END */
    }
    ZendeskUser.prototype.populateExtraFieldsFromUserAPIData = function( APIUserData )
    {
        for(var i = 0; i < this.__extra_user_fields.length; i++) 
        {
            let valueFromAPI = APIUserData.user_fields[ this.__extra_user_fields[ i ].field_def.zendesk_field ];
            if( typeof( valueFromAPI ) === 'undefined' )
            {
                throw new ReferenceError( "The Zendesk 'User Field' with key '" + this.__extra_user_fields[ i ].field_def.zendesk_field + '\' which you specified in your Field Mapping settings doesnt seem to exist in Zendesk yet.<br /><br />For help with your field mappings use our <a target="_blank" href="'+this.__app.__resources.__SETTINGS_HELPER_SPREADSHEET_DOWNLOAD_URL+'">Zenchimp App Settings Generator</a> spreadsheet.' );
            }
            this.__extra_user_fields[ i ].value = APIUserData.user_fields[ this.__extra_user_fields[ i ].field_def.zendesk_field ];
        }
    };



    //get name part functions that convert to title case
    ZendeskUser.prototype.getSalutation = function(){ this.populateNamePartsIfNecessary(); return ( this.__name_parts.salutation === null ) ? "" : this.__name_parts.salutation.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();}); }; //makes not null title case value
    ZendeskUser.prototype.getForeName   = function(){ this.populateNamePartsIfNecessary(); return ( this.__name_parts.firstName === null ) ? "" : this.__name_parts.firstName.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();}); }; //makes not null title case value
    ZendeskUser.prototype.getSurname    = function(){ this.populateNamePartsIfNecessary(); return  ( this.__name_parts.lastName === null ) ? "" : this.__name_parts.lastName.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();}); }; //makes not null title case value
    ZendeskUser.prototype.populateNamePartsIfNecessary = function() 
    { 
        if( this.__name_parts === null && this.name !== null  )
        {
            this.__name_parts = this.__app.parseNamesModule.parse( this.name.replace( "/", " " ).replace( ".", " " ).split(",").reverse().map(Function.prototype.call, String.prototype.trim).join(" ") );
        }
    };
    ZendeskUser.prototype.populateExtraFieldsFromFrameworkUserObject = function( frameworkUserObject )
    {
        for(var i = 0; i < this.__extra_user_fields.length; i++) 
        {
            this.__extra_user_fields[ i ].value = frameworkUserObject.customField( this.__extra_user_fields[ i ].field_def.zendesk_field );
        }
    };
    
    /**
     * inline clone function for user object - deep clones by calling organization.clone too
     * @returns {nm$_ZendeskUser.ZendeskUser.prototype.clone.clonedUser|ZendeskUser.prototype.clone.clonedUser|nm$_ZendeskUser.ZendeskUser}
     */  
    ZendeskUser.prototype.clone = function()
    {
        return new ZendeskUser( this );
    };

    ZendeskUser.prototype.isNotset = function() { return this.customer_type === this.__app.resources.CUSTOMER_TYPE_NOT_SET; };
    ZendeskUser.prototype.isExcluded = function() { return this.customer_type === this.__app.resources.CUSTOMER_TYPE_EXCLUDE; };
    ZendeskUser.prototype.isIncluded = function() { return this.customer_type === this.__app.resources.CUSTOMER_TYPE_USE_ORGANIZATION || this.customer_type === this.__app.resources.CUSTOMER_TYPE_USE_DEFAULT; };
    ZendeskUser.prototype.isOrganization = function() { return this.customer_type === this.__app.resources.CUSTOMER_TYPE_USE_ORGANIZATION; };
    ZendeskUser.prototype.isDefault = function() { return this.customer_type === this.__app.resources.CUSTOMER_TYPE_USE_DEFAULT; };

    ZendeskUser.prototype.belongsToOrganization = function() { return this.__organization_id !== null; };
    ZendeskUser.prototype.__orgObjectIsPopulated = function() { return this.__orgObject !== null; };
    ZendeskUser.prototype.getMailchimpCustomerType = function() 
    { 
        if( typeof( this.customer_type ) === "undefined" || this.customer_type === null )
        {
            console.warn( "ZendeskUser.getMailchimpCustomerType() called with invalid customer_type, this = " );console.dir( this );
            return null;
        }
        return this.customer_type === this.__app.resources.CUSTOMER_TYPE_USE_ORGANIZATION ? this.__orgObject.customer_type : this.__app.__field_maps.cust_type.default_value; 
    };

    ZendeskUser.prototype.findExtraFieldByName = function( fieldName, zdNotMcField )
    {
        for(var i = 0; i < this.__extra_user_fields.length; i++) 
        {
            if( ( zdNotMcField && this.__extra_user_fields[i].field_def.zendesk_field  === fieldName ) || ( !zdNotMcField && this.__extra_user_fields[i].field_def.mailchimp_field === fieldName ) )
            {
                return this.__extra_user_fields[i];
            }
        }
    };

    ZendeskUser.prototype.getFieldSyncInfo = function( mailChimpUser )
    {
        //console.log( "starting getFieldSyncInfo with the following 2 user objects" );
        //console.dir( this ); //console.log( "" );
        //console.dir( mailChimpUser ); //console.log( "" ); 
        if( typeof( mailChimpUser ) === "undefined" || mailChimpUser === null )
        {
            return null;
        }
        if( typeof( this.customer_type ) === "undefined" || this.customer_type === null || this.isNotset() )
        {
            console.warn( "ZendeskUser.getFieldSyncInfo() called with invalid customer_type, this = " );console.dir( this );
            return null;
        }

        //get the mandatory fields that are non-negotiable
        var sync_fields = [
            { label: "Email", mc_only: false, zd_field_location: "user", is_image: false, zd_value: this.email, mc_value: mailChimpUser.email_address, in_sync: ( this.email.toLowerCase() === mailChimpUser.email_address.toLowerCase() ) },
            { label: "Name", mc_only: false, zd_field_location: "user", is_image: false, zd_value: this.name, mc_value: "[" + mailChimpUser.forename + "] [" + mailChimpUser.surname + "]", in_sync: ( mailChimpUser.forename.toLowerCase() === this.getForeName().toLowerCase() && mailChimpUser.surname.toLowerCase() === this.getSurname().toLowerCase() ) },
            { label: "Customer Type", mc_only:false, zd_field_location: "user", is_image: false, zd_value: this.getMailchimpCustomerType(), mc_value: mailChimpUser.customer_type, in_sync: ( this.getMailchimpCustomerType() === mailChimpUser.customer_type ) } 
        ];

        var tempZdValue = null;
        var tempMcValue = null;
        var arrayIndex = 0;
        //console.log( "about to start user fields, JSON:" );
        //console.dir( sync_fields ); //console.log( "" );  
        for( var i = 0; i < this.__extra_user_fields.length; i++ )
        {
            tempZdValue = this.__extra_user_fields[ i ].value;
            tempMcValue = mailChimpUser.extra_merge_fields[ arrayIndex ].value;
            tempZdValue = ( tempZdValue === null ) ? "" : tempZdValue; 
            tempMcValue = ( tempMcValue === null ) ? "" : tempMcValue;
            //add extra conversion here to cast tempMcValue to a string if necessary
            sync_fields[ arrayIndex+3 ] = 
            {
                label: this.__extra_user_fields[ i ].field_def.field_label,
                zd_field_location: "user",
                is_image: this.__extra_user_fields[ i ].field_def.type === this.__app.resources.TYPE_IMAGE,
                zd_value: tempZdValue,
                mc_value: tempMcValue,
                in_sync: tempZdValue === tempMcValue //add extra conversion here to cast tempMcValue to a string if necessary
            };
            arrayIndex++;
        }
        //console.log( "done user fields JSON:" );
        //console.dir( sync_fields ); //console.log( "" );  
        for( i = 0; i < this.__app.__field_maps.organisation.length; i++ )
        {
            tempZdValue = this.isDefault() ? this.__app.__field_maps.organisation[ i ].default_value : ( this.isOrganization() ? this.__orgObject.__extra_org_fields[ i ].__value : null );
            tempMcValue = mailChimpUser.extra_merge_fields[ arrayIndex ].value;
            tempZdValue = ( tempZdValue === null ) ? "" : tempZdValue; 
            tempMcValue = ( tempMcValue === null ) ? "" : tempMcValue;
            //add extra conversion here to cast tempMcValue to a string if necessary
            sync_fields[ arrayIndex+3 ] = 
            {
                label: this.__app.__field_maps.organisation[ i ].field_label,
                zd_field_location: "organisation",
                is_image: this.__app.__field_maps.organisation[ i ].type === this.__app.resources.TYPE_IMAGE,
                zd_value: tempZdValue,
                mc_value: tempMcValue,
                in_sync: tempZdValue === tempMcValue //add extra conversion here to cast tempMcValue to a string if necessary
            };
            arrayIndex++;
        }
        //console.log( "done org fields JSON:" );
        //console.dir( sync_fields ); //console.log( "" );
        
        for( i = 0; i < this.__app.__field_maps.mc_only.length; i++ )
        {
            tempMcValue = mailChimpUser.extra_merge_fields[ arrayIndex ].value;
            tempMcValue = ( tempMcValue === null ) ? "" : tempMcValue;
            //add extra conversion here to cast tempMcValue to a string if necessary
            sync_fields[ arrayIndex+3 ] = 
            {
                label: this.__app.__field_maps.mc_only[ i ].field_label,
                zd_field_location: null,
                is_image: this.__app.__field_maps.mc_only[ i ].type === this.__app.resources.TYPE_IMAGE,
                is_checkbox: this.__app.__field_maps.mc_only[ i ].type === this.__app.resources.TYPE_CHECKBOX,
                is_checkbox_ticked: this.__app.__field_maps.mc_only[ i ].type !== this.__app.resources.TYPE_CHECKBOX ? 
                    null : 
                    tempMcValue === "1" || tempMcValue === 1 ? true : false, 
                zd_value: null,
                mc_value: tempMcValue,
                in_sync: true
            };
            arrayIndex++;
        }   

        return sync_fields;
    };

    ZendeskUser.prototype.isInSync = function( syncFields, mailChimpUser )
    {
        if( typeof( syncFields ) === "undefined" || syncFields === null )
        {
           syncFields = this.getFieldSyncInfo( mailChimpUser );
        }

        if( syncFields === null )
        {
            return false;
        }

        for(var i=0; i < syncFields.length; i++ )
        {
            if( !syncFields[ i ].in_sync )
            {
                return false;
            }
        }
        return true;
    };