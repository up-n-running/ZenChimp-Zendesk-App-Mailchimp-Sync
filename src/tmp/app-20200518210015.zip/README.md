# John's bespoke Zendesk Plugin to Sync Contacts with Mailchimp without having to upgrade to 'Customer Lists' in Zendesk

Just install and configure to map the zendesk fields to the mailchimp fields and you will have a fully incorporated fuly functional additional section on your zendesk ticket screen and contact screen to seamlessly allow you to push contact data from Zendesk to Mailchimp.

It used to work really well and I used it commercially over a year.

**PLEASE NOTE: It's no longer compliant since framework v1 was discontinued. I'm in the process of updating it to use latest version of framework - Watch this space it shouldnt be long (17/May/2020)**

Please submit bug reports to [john@upnrunning.co.uk](). Pull requests are welcome.
