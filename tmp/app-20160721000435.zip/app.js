(function() {

/*
{"members":[{"id":"efa58ba4eca762268885f70e2b19485c","email_address":"tmistry@hoovercandy.com","unique_email_id":"8f4079846c","email_type":"html","status":"subscribed","merge_fields":{"FNAME":"Tamanna","LNAME":"Mistry","FROMEMAIL":"hoover.success@greenlightpower.net","LOGO":"https://gallery.mailchimp.com/a0a70a7c775f05e19e19fa7aa/images/a0c4d50a-ce23-44d4-adc6-f58a3cb3ca6d.png","CUSTOMER":"Hoover","SEND_MAINT":1,"SEND_ANNOU":1},"stats":{"avg_open_rate":0,"avg_click_rate":0},"ip_signup":"","timestamp_signup":"","ip_opt":"94.197.120.180","timestamp_opt":"2016-07-01T18:44:02+00:00","member_rating":2,"last_changed":"2016-07-08T16:45:09+00:00","language":"","vip":false,"email_client":"","location":{"latitude":0,"longitude":0,"gmtoff":0,"dstoff":0,"country_code":"","timezone":""},"list_id":"78ecb74923","_links":[{"rel":"self","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/efa58ba4eca762268885f70e2b19485c","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"parent","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Collection.json","schema":"https://us13.api.mailchimp.com/schema/3.0/CollectionLinks/Lists/Members.json"},{"rel":"update","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/efa58ba4eca762268885f70e2b19485c","method":"PATCH","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"upsert","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/efa58ba4eca762268885f70e2b19485c","method":"PUT","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"delete","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/efa58ba4eca762268885f70e2b19485c","method":"DELETE"},{"rel":"activity","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/efa58ba4eca762268885f70e2b19485c/activity","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Activity/Collection.json"},{"rel":"goals","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/efa58ba4eca762268885f70e2b19485c/goals","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Goals/Collection.json"},{"rel":"notes","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/efa58ba4eca762268885f70e2b19485c/notes","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Notes/Collection.json"}]},{"id":"b75cd24839866a8b67e5dc99da01dde4","email_address":"dwaddington@hoovercandy.com","unique_email_id":"614f7941d1","email_type":"html","status":"subscribed","merge_fields":{"FNAME":"dwaddington","LNAME":"","FROMEMAIL":"hoover.success@greenlightpower.net","LOGO":"https://gallery.mailchimp.com/a0a70a7c775f05e19e19fa7aa/images/a0c4d50a-ce23-44d4-adc6-f58a3cb3ca6d.png","CUSTOMER":"Hoover","SEND_MAINT":0,"SEND_ANNOU":1},"stats":{"avg_open_rate":0,"avg_click_rate":0},"ip_signup":"","timestamp_signup":"","ip_opt":"94.197.120.180","timestamp_opt":"2016-07-01T18:44:02+00:00","member_rating":2,"last_changed":"2016-07-08T16:45:09+00:00","language":"","vip":false,"email_client":"","location":{"latitude":0,"longitude":0,"gmtoff":0,"dstoff":0,"country_code":"","timezone":""},"list_id":"78ecb74923","_links":[{"rel":"self","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/b75cd24839866a8b67e5dc99da01dde4","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"parent","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Collection.json","schema":"https://us13.api.mailchimp.com/schema/3.0/CollectionLinks/Lists/Members.json"},{"rel":"update","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/b75cd24839866a8b67e5dc99da01dde4","method":"PATCH","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"upsert","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/b75cd24839866a8b67e5dc99da01dde4","method":"PUT","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"delete","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/b75cd24839866a8b67e5dc99da01dde4","method":"DELETE"},{"rel":"activity","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/b75cd24839866a8b67e5dc99da01dde4/activity","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Activity/Collection.json"},{"rel":"goals","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/b75cd24839866a8b67e5dc99da01dde4/goals","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Goals/Collection.json"},{"rel":"notes","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/b75cd24839866a8b67e5dc99da01dde4/notes","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Notes/Collection.json"}]},{"id":"29172e7c7cf2242b1db059890bac1545","email_address":"gevans@hoovercandy.com","unique_email_id":"d06483ca71","email_type":"html","status":"subscribed","merge_fields":{"FNAME":"Gavin","LNAME":"Evans","FROMEMAIL":"hoover.success@greenlightpower.net","LOGO":"https://gallery.mailchimp.com/a0a70a7c775f05e19e19fa7aa/images/a0c4d50a-ce23-44d4-adc6-f58a3cb3ca6d.png","CUSTOMER":"Hoover","SEND_MAINT":0,"SEND_ANNOU":1},"stats":{"avg_open_rate":0,"avg_click_rate":0},"ip_signup":"","timestamp_signup":"","ip_opt":"94.197.120.180","timestamp_opt":"2016-07-01T18:44:02+00:00","member_rating":2,"last_changed":"2016-07-08T16:45:09+00:00","language":"","vip":false,"email_client":"","location":{"latitude":0,"longitude":0,"gmtoff":0,"dstoff":0,"country_code":"","timezone":""},"list_id":"78ecb74923","_links":[{"rel":"self","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/29172e7c7cf2242b1db059890bac1545","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"parent","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Collection.json","schema":"https://us13.api.mailchimp.com/schema/3.0/CollectionLinks/Lists/Members.json"},{"rel":"update","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/29172e7c7cf2242b1db059890bac1545","method":"PATCH","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"upsert","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/29172e7c7cf2242b1db059890bac1545","method":"PUT","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"delete","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/29172e7c7cf2242b1db059890bac1545","method":"DELETE"},{"rel":"activity","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/29172e7c7cf2242b1db059890bac1545/activity","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Activity/Collection.json"},{"rel":"goals","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/29172e7c7cf2242b1db059890bac1545/goals","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Goals/Collection.json"},{"rel":"notes","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/29172e7c7cf2242b1db059890bac1545/notes","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Notes/Collection.json"}]},{"id":"1ddde92d837dce130dcefbe4182cd774","email_address":"lplatt@hoovercandy.com","unique_email_id":"9bb0d361bb","email_type":"html","status":"subscribed","merge_fields":{"FNAME":"Louise","LNAME":"Platt","FROMEMAIL":"hoover.success@greenlightpower.net","LOGO":"https://gallery.mailchimp.com/a0a70a7c775f05e19e19fa7aa/images/a0c4d50a-ce23-44d4-adc6-f58a3cb3ca6d.png","CUSTOMER":"Hoover","SEND_MAINT":0,"SEND_ANNOU":0},"stats":{"avg_open_rate":0,"avg_click_rate":0},"ip_signup":"","timestamp_signup":"","ip_opt":"94.197.120.180","timestamp_opt":"2016-07-01T18:44:02+00:00","member_rating":2,"last_changed":"2016-07-08T16:45:09+00:00","language":"","vip":false,"email_client":"","location":{"latitude":0,"longitude":0,"gmtoff":0,"dstoff":0,"country_code":"","timezone":""},"list_id":"78ecb74923","_links":[{"rel":"self","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/1ddde92d837dce130dcefbe4182cd774","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"parent","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Collection.json","schema":"https://us13.api.mailchimp.com/schema/3.0/CollectionLinks/Lists/Members.json"},{"rel":"update","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/1ddde92d837dce130dcefbe4182cd774","method":"PATCH","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"upsert","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/1ddde92d837dce130dcefbe4182cd774","method":"PUT","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"delete","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/1ddde92d837dce130dcefbe4182cd774","method":"DELETE"},{"rel":"activity","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/1ddde92d837dce130dcefbe4182cd774/activity","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Activity/Collection.json"},{"rel":"goals","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/1ddde92d837dce130dcefbe4182cd774/goals","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Goals/Collection.json"},{"rel":"notes","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/1ddde92d837dce130dcefbe4182cd774/notes","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Notes/Collection.json"}]},{"id":"894c52eeb001b10744a4ec65aa5d5334","email_address":"lee.wilkes@hoovercandy.com","unique_email_id":"e2ea7adde4","email_type":"html","status":"subscribed","merge_fields":{"FNAME":"Lee","LNAME":"Wilkes","FROMEMAIL":"hoover.success@greenlightpower.net","LOGO":"https://gallery.mailchimp.com/a0a70a7c775f05e19e19fa7aa/images/a0c4d50a-ce23-44d4-adc6-f58a3cb3ca6d.png","CUSTOMER":"Hoover","SEND_MAINT":1,"SEND_ANNOU":1},"stats":{"avg_open_rate":0,"avg_click_rate":0},"ip_signup":"","timestamp_signup":"","ip_opt":"94.197.120.180","timestamp_opt":"2016-07-01T18:44:02+00:00","member_rating":2,"last_changed":"2016-07-08T16:45:09+00:00","language":"","vip":false,"email_client":"","location":{"latitude":0,"longitude":0,"gmtoff":0,"dstoff":0,"country_code":"","timezone":""},"list_id":"78ecb74923","_links":[{"rel":"self","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/894c52eeb001b10744a4ec65aa5d5334","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"parent","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Collection.json","schema":"https://us13.api.mailchimp.com/schema/3.0/CollectionLinks/Lists/Members.json"},{"rel":"update","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/894c52eeb001b10744a4ec65aa5d5334","method":"PATCH","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"upsert","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/894c52eeb001b10744a4ec65aa5d5334","method":"PUT","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"delete","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/894c52eeb001b10744a4ec65aa5d5334","method":"DELETE"},{"rel":"activity","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/894c52eeb001b10744a4ec65aa5d5334/activity","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Activity/Collection.json"},{"rel":"goals","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/894c52eeb001b10744a4ec65aa5d5334/goals","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Goals/Collection.json"},{"rel":"notes","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/894c52eeb001b10744a4ec65aa5d5334/notes","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Notes/Collection.json"}]},{"id":"4718115b1ba7dde7b8fee1bc2bda6ba7","email_address":"sskinner@hoovercandy.com","unique_email_id":"3fb3326561","email_type":"html","status":"subscribed","merge_fields":{"FNAME":"Simon","LNAME":"Skinner","FROMEMAIL":"hoover.success@greenlightpower.net","LOGO":"https://gallery.mailchimp.com/a0a70a7c775f05e19e19fa7aa/images/a0c4d50a-ce23-44d4-adc6-f58a3cb3ca6d.png","CUSTOMER":"Hoover","SEND_MAINT":1,"SEND_ANNOU":1},"stats":{"avg_open_rate":1,"avg_click_rate":1},"ip_signup":"","timestamp_signup":"","ip_opt":"94.197.120.180","timestamp_opt":"2016-07-01T18:44:02+00:00","member_rating":4,"last_changed":"2016-07-08T16:45:09+00:00","language":"","vip":false,"email_client":"Outlook 2013","location":{"latitude":52.4325,"longitude":-1.81834,"gmtoff":0,"dstoff":1,"country_code":"GB","timezone":"Atlantic/Faroe"},"list_id":"78ecb74923","_links":[{"rel":"self","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/4718115b1ba7dde7b8fee1bc2bda6ba7","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"parent","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Collection.json","schema":"https://us13.api.mailchimp.com/schema/3.0/CollectionLinks/Lists/Members.json"},{"rel":"update","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/4718115b1ba7dde7b8fee1bc2bda6ba7","method":"PATCH","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"upsert","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/4718115b1ba7dde7b8fee1bc2bda6ba7","method":"PUT","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"delete","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/4718115b1ba7dde7b8fee1bc2bda6ba7","method":"DELETE"},{"rel":"activity","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/4718115b1ba7dde7b8fee1bc2bda6ba7/activity","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Activity/Collection.json"},{"rel":"goals","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/4718115b1ba7dde7b8fee1bc2bda6ba7/goals","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Goals/Collection.json"},{"rel":"notes","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/4718115b1ba7dde7b8fee1bc2bda6ba7/notes","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Notes/Collection.json"}]},{"id":"a2c90f6a4e57e6f3353a77ef7f1acffa","email_address":"lwilkes@hoovercandy.com","unique_email_id":"a0889a791b","email_type":"html","status":"subscribed","merge_fields":{"FNAME":"Lee","LNAME":"Wilkes","FROMEMAIL":"hoover.success@greenlightpower.net","LOGO":"https://gallery.mailchimp.com/a0a70a7c775f05e19e19fa7aa/images/a0c4d50a-ce23-44d4-adc6-f58a3cb3ca6d.png","CUSTOMER":"Hoover","SEND_MAINT":1,"SEND_ANNOU":1},"stats":{"avg_open_rate":0,"avg_click_rate":0},"ip_signup":"","timestamp_signup":"","ip_opt":"94.197.120.180","timestamp_opt":"2016-07-01T18:44:02+00:00","member_rating":2,"last_changed":"2016-07-08T16:45:09+00:00","language":"","vip":false,"email_client":"","location":{"latitude":0,"longitude":0,"gmtoff":0,"dstoff":0,"country_code":"","timezone":""},"list_id":"78ecb74923","_links":[{"rel":"self","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/a2c90f6a4e57e6f3353a77ef7f1acffa","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"parent","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Collection.json","schema":"https://us13.api.mailchimp.com/schema/3.0/CollectionLinks/Lists/Members.json"},{"rel":"update","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/a2c90f6a4e57e6f3353a77ef7f1acffa","method":"PATCH","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"upsert","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/a2c90f6a4e57e6f3353a77ef7f1acffa","method":"PUT","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"delete","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/a2c90f6a4e57e6f3353a77ef7f1acffa","method":"DELETE"},{"rel":"activity","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/a2c90f6a4e57e6f3353a77ef7f1acffa/activity","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Activity/Collection.json"},{"rel":"goals","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/a2c90f6a4e57e6f3353a77ef7f1acffa/goals","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Goals/Collection.json"},{"rel":"notes","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/a2c90f6a4e57e6f3353a77ef7f1acffa/notes","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Notes/Collection.json"}]},{"id":"60166bf9b6ae949dd9b708d65f7a4d73","email_address":"roberto.rotta@candy.it","unique_email_id":"a5b655060e","email_type":"html","status":"subscribed","merge_fields":{"FNAME":"Roberto","LNAME":"Rotta","FROMEMAIL":"hoover.success@greenlightpower.net","LOGO":"https://gallery.mailchimp.com/a0a70a7c775f05e19e19fa7aa/images/a0c4d50a-ce23-44d4-adc6-f58a3cb3ca6d.png","CUSTOMER":"Hoover","SEND_MAINT":1,"SEND_ANNOU":0},"stats":{"avg_open_rate":0,"avg_click_rate":0},"ip_signup":"","timestamp_signup":"","ip_opt":"94.197.120.180","timestamp_opt":"2016-07-01T18:44:02+00:00","member_rating":2,"last_changed":"2016-07-08T16:45:09+00:00","language":"","vip":false,"email_client":"","location":{"latitude":0,"longitude":0,"gmtoff":0,"dstoff":0,"country_code":"","timezone":""},"list_id":"78ecb74923","_links":[{"rel":"self","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/60166bf9b6ae949dd9b708d65f7a4d73","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"parent","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Collection.json","schema":"https://us13.api.mailchimp.com/schema/3.0/CollectionLinks/Lists/Members.json"},{"rel":"update","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/60166bf9b6ae949dd9b708d65f7a4d73","method":"PATCH","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"upsert","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/60166bf9b6ae949dd9b708d65f7a4d73","method":"PUT","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"delete","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/60166bf9b6ae949dd9b708d65f7a4d73","method":"DELETE"},{"rel":"activity","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/60166bf9b6ae949dd9b708d65f7a4d73/activity","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Activity/Collection.json"},{"rel":"goals","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/60166bf9b6ae949dd9b708d65f7a4d73/goals","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Goals/Collection.json"},{"rel":"notes","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/60166bf9b6ae949dd9b708d65f7a4d73/notes","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Notes/Collection.json"}]},{"id":"d6acc35fdec6b59208c6e7e6440aeb84","email_address":"ajeffery@hoovercandy.com","unique_email_id":"66d68c0b53","email_type":"html","status":"subscribed","merge_fields":{"FNAME":"Alun","LNAME":"Jeffery","FROMEMAIL":"hoover.success@greenlightpower.net","LOGO":"https://gallery.mailchimp.com/a0a70a7c775f05e19e19fa7aa/images/a0c4d50a-ce23-44d4-adc6-f58a3cb3ca6d.png","CUSTOMER":"Hoover","SEND_MAINT":1,"SEND_ANNOU":1},"stats":{"avg_open_rate":0,"avg_click_rate":0},"ip_signup":"","timestamp_signup":"","ip_opt":"94.197.120.180","timestamp_opt":"2016-07-01T18:44:02+00:00","member_rating":2,"last_changed":"2016-07-08T16:45:09+00:00","language":"","vip":false,"email_client":"","location":{"latitude":0,"longitude":0,"gmtoff":0,"dstoff":0,"country_code":"","timezone":""},"list_id":"78ecb74923","_links":[{"rel":"self","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/d6acc35fdec6b59208c6e7e6440aeb84","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"parent","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Collection.json","schema":"https://us13.api.mailchimp.com/schema/3.0/CollectionLinks/Lists/Members.json"},{"rel":"update","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/d6acc35fdec6b59208c6e7e6440aeb84","method":"PATCH","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"upsert","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/d6acc35fdec6b59208c6e7e6440aeb84","method":"PUT","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"delete","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/d6acc35fdec6b59208c6e7e6440aeb84","method":"DELETE"},{"rel":"activity","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/d6acc35fdec6b59208c6e7e6440aeb84/activity","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Activity/Collection.json"},{"rel":"goals","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/d6acc35fdec6b59208c6e7e6440aeb84/goals","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Goals/Collection.json"},{"rel":"notes","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/d6acc35fdec6b59208c6e7e6440aeb84/notes","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Notes/Collection.json"}]},{"id":"c1b6757171a9c402e045ad063ba83894","email_address":"hoover.success@greenlightpower.net","unique_email_id":"67a7012181","email_type":"html","status":"subscribed","merge_fields":{"FNAME":"Colleagues","LNAME":"Greenlight Power","FROMEMAIL":"hoover.success@greenlightpower.net","LOGO":"https://gallery.mailchimp.com/a0a70a7c775f05e19e19fa7aa/images/a0c4d50a-ce23-44d4-adc6-f58a3cb3ca6d.png","CUSTOMER":"Hoover","SEND_MAINT":1,"SEND_ANNOU":1},"stats":{"avg_open_rate":1,"avg_click_rate":1},"ip_signup":"","timestamp_signup":"2016-07-06T09:10:39+00:00","ip_opt":"","timestamp_opt":"2016-07-06T09:10:39+00:00","member_rating":3,"last_changed":"2016-07-08T16:45:09+00:00","language":"","vip":false,"email_client":"Outlook 2016","location":{"latitude":53.4024,"longitude":-2.833,"gmtoff":0,"dstoff":1,"country_code":"GB","timezone":"Atlantic/Faroe"},"list_id":"78ecb74923","_links":[{"rel":"self","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/c1b6757171a9c402e045ad063ba83894","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"parent","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Collection.json","schema":"https://us13.api.mailchimp.com/schema/3.0/CollectionLinks/Lists/Members.json"},{"rel":"update","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/c1b6757171a9c402e045ad063ba83894","method":"PATCH","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"upsert","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/c1b6757171a9c402e045ad063ba83894","method":"PUT","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"},{"rel":"delete","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/c1b6757171a9c402e045ad063ba83894","method":"DELETE"},{"rel":"activity","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/c1b6757171a9c402e045ad063ba83894/activity","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Activity/Collection.json"},{"rel":"goals","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/c1b6757171a9c402e045ad063ba83894/goals","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Goals/Collection.json"},{"rel":"notes","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members/c1b6757171a9c402e045ad063ba83894/notes","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Notes/Collection.json"}]}],"list_id":"78ecb74923","total_items":65,"_links":[{"rel":"self","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Collection.json","schema":"https://us13.api.mailchimp.com/schema/3.0/CollectionLinks/Lists/Members.json"},{"rel":"parent","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923","method":"GET","targetSchema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Instance.json"},{"rel":"create","href":"https://us13.api.mailchimp.com/3.0/lists/78ecb74923/members","method":"POST","schema":"https://us13.api.mailchimp.com/schema/3.0/Lists/Members/Instance.json"}]}Johns-MacBook-Air:~ johnmilner$ 
*/

console.log("Loading app.js");

  return {

    defaultState: 'loading_screen',

    resources: 
    {
      APP_LOCATION_TICKET: "ticket_sidebar",
      APP_LOCATION_USER: "user_sidebar",

      USER_FIELD_NAME_EXTERNAL_ID: "mailshot_external_subscriberid",
      USER_FIELD_NAME_CUSTOMER_TYPE: "mailshot_customer_type",
      USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_NOT_SET: null,
      USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_EXCLUDE: "mailshot_exclude_from_mailshot",
      USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_DEFAULT: "mailshot_use_default_values",
      USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_ORGANIZATION: "mailshot_use_organisation_values",

      TEMPLATE_NAME_MAIN: "main",

      DATE_PATTERN : /^\d{4}-\d{2}-\d{2}$/
    },

    events: 
    {
      'app.activated'                : 'init',

      // Requests
      'getZendeskUser.done'			: 'gotOrSetUserFromDataAPI',
      'getZendeskUser.fail'			: 'switchToErrorMessage',
      'updateZendeskUser.done'		: 'gotOrSetUserFromDataAPI',
      'updateZendeskUser.fail'		: 'switchToErrorMessage',
      'getMailChimpListMember.done'	: 'retrievedMailchimpSubscriber',
      'getMailChimpListMember.fail'	: 'switchToErrorMessage',       
      'getMailChimpAllListMembers.done'	: 'retrievedMailchimpAllListSubscribers',
      'getMailChimpAllListMembers.fail'	: 'switchToErrorMessage',    

      //buttons
      'click .exclude' 				: 'excludeButtonOnClick',
      'click .organization' 		: 'organizationButtonOnClick',
      'click .standard' 			: 'standardButtonOnClick',

      //main screen events
      'user.mailshot_customer_type.changed' : 'userScreenCustomerTypeFieldChanged'
    },

    requests: 
    {
    	getZendeskUser: function(id)
    	{
    		var userApiCallSettings = 
    		{
				url: helpers.fmt('/api/v2/users/%@.json', id),
				type:'GET',
				dataType: 'json'
			};
			console.log( "API CAll DETAILS FOR getZendeskUser;" );
			console.dir( userApiCallSettings ); console.log();
        	return userApiCallSettings;
		},

		updateZendeskUser: function( userToSyncObject )
		{
    		var userApiCallSettings = 
    		{
				url: '/api/v2/users/create_or_update.json',
				type:'POST',
				dataType: 'json',
				contentType: 'application/json',
				data: JSON.stringify(
				{
					'user': 
					{ 
						'id': userToSyncObject.id, 
						'email': userToSyncObject.email,
						'user_fields':
						{
							'mailshot_customer_type': userToSyncObject.customer_type
						}
					}
				})
			};
			console.log( "API CAll DETAILS FOR createOrUpdateZendeskUser;" );
			console.dir( userApiCallSettings ); console.log();
        	return userApiCallSettings;
		},

		getMailChimpListMember: function( subscriberId )
		{
			var jsonCall =
			{
				url: helpers.fmt( "https://%@.api.mailchimp.com/2.0/lists/member-info.json", this.mailchimp_datacentre_prefix ),
				type: 'POST',
				dataType: 'json',
				contentType: 'application/json; charset=UTF-8',
				data: JSON.stringify(
				{
					"apikey": this.mailchimp_api_key,
					"id": this.mailchimp_list_id,
				    "emails": [
				        {
				            "email": null,
				            "euid": null,
				            "leid": subscriberId
				        }
				    ]
				})
			};
			console.log( "API CAll DETAILS FOR getMailChimpListMember;" );
			console.dir( jsonCall ); console.log();
			return jsonCall;
		},

		getMailChimpAllListMembers: function()
		{
			var jsonCall =
			{
				//url: "https://us13.api.mailchimp.com/2.0/lists/members",
				url: helpers.fmt( "https://%@.api.mailchimp.com/2.0/lists/members.json", this.mailchimp_datacentre_prefix ),
				type: 'POST',
				dataType: 'json',
				contentType: 'application/json; charset=UTF-8',
				data: JSON.stringify(
				{
					"apikey": this.mailchimp_api_key,
					"id": this.mailchimp_list_id,
					"status": "subscribed",
					"opts": {
					    "start": 0,
					    "limit": 100,
					    "sort_field": "email",
					    "sort_dir": "ASC"
					}
				})
			};
			console.log( "API CAll DETAILS FOR getMailChimpAllListMembers;" );
			console.dir( jsonCall ); console.log();
			return jsonCall;
		},

		updateMailChimpListMember: function( subscriberId )
		{
			var jsonCall =
			{
				url: helpers.fmt( "https://%@.api.mailchimp.com/2.0/lists/member-info.json", this.mailchimp_datacentre_prefix ),
				type: 'POST',
				dataType: 'json',
				contentType: 'application/json; charset=UTF-8',
				data: JSON.stringify(
				{
					"apikey": this.mailchimp_api_key,
					"id": this.mailchimp_list_id,
				    "emails": [
				        {
				            "email": null,
				            "euid": null,
				            "leid": subscriberId
				        }
				    ]
				})
			};
			console.log( "API CAll DETAILS FOR getMailChimpListMember;" );
			console.dir( jsonCall ); console.log();
			return jsonCall;
		}

	},

    // --- initialization functions
    init: function() 
    {
    	console.log( "Starting init");
    	console.log( "Location Object:" );
    	console.dir( this.currentLocation() );
    	console.log( "This =" );
		console.dir( this );
        
        //Get Settings from manifest.js
		this.mailchimp_api_key = this.setting('mailchimp_api_key');
		this.mailchimp_datacentre_prefix = this.setting('mailchimp_datacentre_prefix');
		this.mailchimp_list_id = this.setting('mailchimp_list_id');

		//fetch current user object and use it to store gloabl user variables for use later
		this.zendesk_user_object_to_sync = null;
		if( this.currentLocation() == this.resources.APP_LOCATION_TICKET )
		{
			this.ajax( 'getZendeskUser', this.ticket().requester().id() );
		}
		else if( this.currentLocation() == this.resources.APP_LOCATION_USER )
		{
//CHECK HERE IF USER WAS UPDATED ELSEWHERE!
			this.getUserFromFrameworkInUserSidebarLocation();
		}

		//this.ajax( 'getMailChimpAllListMembers' );
    },

    getUserFromFrameworkInUserSidebarLocation: function()
    {
		console.log( 'Starting getUserFromFrameworkInUserSidebarLocation' );
		console.log( 'this.user() object from framework = ' );
		console.dir( this.user() );
		console.log( 'this.userFields() object from framework = ' );
		console.dir( this.userFields() );
		console.log( 'this.user().organizations() object from framework = ' );
		console.dir( this.user().organizations() );
		console.log( 'this.user().organizations()[0] object from framework = ' );
		console.dir( this.user().organizations()[0] );

		this.zendesk_user_object_to_sync = 
		{
			id: this.user().id(),
			name: this.user().name(),
			email: this.user().email(),
			organization: ( typeof( this.user().organizations()[0] ) == 'undefined' ) ? null : { id: this.user().organizations()[0].id(), name: this.user().organizations()[0].name() },
			customer_type: this.user().customField( this.resources.USER_FIELD_NAME_CUSTOMER_TYPE ),
			external_subscriber_id: this.user().customField( this.resources.USER_FIELD_NAME_EXTERNAL_ID )
		};
		this.userDataInitialized();
    },

	gotOrSetUserFromDataAPI: function( userObjectFromDataAPI )
	{
		console.log( 'Starting gotOrSetUserFromDataAPI' );
		console.log( 'user object from API = ' );
		console.dir( userObjectFromDataAPI );


		if( userObjectFromDataAPI != null )
		{
			this.zendesk_user_object_to_sync = 
			{
				id: userObjectFromDataAPI.user.id,
				name: userObjectFromDataAPI.user.name,
				email: userObjectFromDataAPI.user.email,
				//ORG_ID: userObjectFromDataAPI.user.organization_id,
				organization: ( userObjectFromDataAPI.user.organization_id == null ) ? null : { id: userObjectFromDataAPI.user.organization_id, name: null },
				customer_type: userObjectFromDataAPI.user.user_fields.mailshot_customer_type,
				external_subscriber_id: userObjectFromDataAPI.user.user_fields.mailshot_external_subscriberid
			};
			this.userDataInitialized();
		}
		else console.warn( "gotOrSetUserFromDataAPI called but userObjectFromDataAPI = null - this should never happen!");
	},

	userDataInitialized: function()
	{
		if( this.zendesk_user_object_to_sync != null )
		{
			console.log( 'user object = ' );
			console.dir( this.zendesk_user_object_to_sync );

			//user is definitely initialised so lets see if they are new and havent been configured for mailshot settings yet
			if( this.zendesk_user_object_to_sync.customer_type == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_NOT_SET )
			{
				this.switchToMainTemplate();
			}
			else if( this.zendesk_user_object_to_sync.customer_type == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_EXCLUDE )
			{
				this.switchToMainTemplate();
			}
			else
			{
				this.ajax( 'getMailChimpListMember', this.zendesk_user_object_to_sync.external_subscriber_id );
			}
		}
		else console.warn( "userDataInitialized called but this.zendesk_user_object_to_sync = null - this should never happen!");
	},  
    
	retrievedMailchimpSubscriber: function( mailchimpSubscriber ) 
	{

		console.log( "started retrievedMailchimpSubscriber with the following object:" );
		console.dir( mailchimpSubscriber ); console.log( "" );
		this.switchToMainTemplate();
	},

	retrievedMailchimpAllListSubscribers: function( mailchimpSubscriberList ) 
	{

		console.log( "started retrievedMailchimpAllListSubscribers with the following object:" );
		console.dir( mailchimpSubscriberList ); console.log( "" );
		//this.switchToMainTemplate();
	},	

	changeCustomerType: function( oldType, newType ) 
	{
		console.log( "changeCustomerType called" );
		console.log( "oldType: " + oldType );
		console.log( "newType: " + newType );		
		//update user object to keep track of change
		this.zendesk_user_object_to_sync.customer_type = newType;

		//NOW TAKE APPROPRIATE ACTION DEPENDING ON OLD AND NEW VALUE

		//if NOT SET or EXCLUDE were selected 
		if( newType == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_NOT_SET || newType == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_EXCLUDE  )
		{
			//if NOT SET or EXCLUDE were selected AND it was previously set to STANDARD or ORGANIZATION
			if( oldType == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_DEFAULT || oldType == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_ORGANIZATION )
			{
console.log ("INSERT CODE HERE TO ADD REMOVE USER FROM MAILCHIMP VIA MAILCHIMP API - if id is not set maybe throw error or maybe just delete by email address");
//then probably remove the line of code below
				//reload the app with new updated user object
				this.switchToMainTemplate();
			}
			//if NOT SET or EXCLUDE were selected AND it was previously set to the other one
			if( oldType != newType )
			{
				//reload the app template with new updated user object - no need to call mailchimp API
				this.switchToMainTemplate();
			}
		}

		//if ORGANIZATION or STANDARD was selected
		if( newType == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_ORGANIZATION || newType == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_DEFAULT  )
		{
			//if ORGANIZATION or STANDARD  were selected AND it was previously set to EXCLUDE or NOT SET
			if( oldType == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_EXCLUDE || oldType == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_NOT_SET )
			{
console.log ("INSERT CODE HERE TO ADD USER TO MAILCHIMP VIA MAILCHIMP API - if id is not set then update if email match and add if not");
//then probably remove the line of code below
				//reload the app with new updated user object
				this.switchToMainTemplate();
			}
			//if ORGANIZATION or STANDARD  were selected AND it was previously set to the other one
			else if( oldType != newType )
			{
console.log ("INSERT CODE HERE TO ADD UPDATE USER IN MAILCHIMP VIA MAILCHIMP API - if id is not set then update if email match and add if not");
//then probably remove the line of code below
				this.switchToMainTemplate();
			}
		}
	},

    //MOVE THIS UP ONCE DONE
/*	updtedUserFromDataAPI: function( resultsObjectFromDataAPI )
	{
		console.log( 'Starting updtedUserFromDataAPI' );
		console.log( 'resultsObjectFromDataAPI object from API = ' );
		console.dir( resultsObjectFromDataAPI );

		if( this.zendesk_user_object_to_sync == null && userObjectFromDataAPI != null )
		{
			this.zendesk_user_object_to_sync = 
			{
				id: userObjectFromDataAPI.user.id,
				name: userObjectFromDataAPI.user.name,
				email: userObjectFromDataAPI.user.email,
				//ORG_ID: userObjectFromDataAPI.user.organization_id,
				organization: ( userObjectFromDataAPI.user.organization_id == null ) ? null : { id: userObjectFromDataAPI.user.organization_id, name: null },
				customer_type: userObjectFromDataAPI.user.user_fields.mailshot_customer_type,
				external_subscriber_id: userObjectFromDataAPI.user.user_fields.mailshot_external_subscriberid
			};
			this.userDataInitialized();
		}
		else console.warn( "gotOrSetUserFromDataAPI called but this.zendesk_user_object_to_sync != null or userObjectFromDataAPI = null - this should never happen!");
	},*/

    //UTIL FUNCTIONS
    cloneUserToSyncObject: function( origUser ) 
    {

		return (origUser == null ) ? null :
		{
			id: origUser.id,
			name: origUser.name,
			email: origUser.email,
			organization: this.cloneUserToSyncOrganisationObject( origUser.organization ),
			customer_type: origUser.customer_type,
			external_subscriber_id: origUser.external_subscriber_id
		};
    },

    cloneUserToSyncOrganisationObject: function( origUserOrganisation ) 
    {

		return (origUserOrganisation == null ) ? null :
		{
			id: origUserOrganisation.id,
			name: origUserOrganisation.name,
		};
    },

    //MAIN SCREEN UTILITY FUNCTIONS
    hideFieldsIfInUserLocation: function() 
    {
      /* _.each([this.timeFieldLabel(), this.totalTimeFieldLabel()], function(f) {
        var field = this.ticketFields(f);

        if (field && field.isVisible()) {
          field.hide();
        }
      }, this); */
    },


	//APP FIELD ONCLICK FUNCTIONS
	excludeButtonOnClick: function()
	{
		console.log( "started excludeButtonOnClick" );
		if( this.currentLocation() == this.resources.APP_LOCATION_USER )
		{
			console.dir(  this.user().customField( this.resources.USER_FIELD_NAME_CUSTOMER_TYPE, this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_EXCLUDE ) );
		    //thsi triggers userScreenCustomerTypeFieldChanged to be changed so no need to make any further calls
		}
		else 
		{
			//update via apis
			var updatedUserToSave = this.cloneUserToSyncObject( this.zendesk_user_object_to_sync );
			updatedUserToSave.customer_type = this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_EXCLUDE;
			console.log( "About to save user:");
			console.dir( updatedUserToSave );
			this.ajax( 'updateZendeskUser', updatedUserToSave );
		}

	},

	organizationButtonOnClick: function()
	{
		console.log( "started organizationButtonOnClick" );
		if( this.currentLocation() == this.resources.APP_LOCATION_USER )
		{
			console.dir(  this.user().customField( this.resources.USER_FIELD_NAME_CUSTOMER_TYPE, this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_ORGANIZATION ) );
		    //thsi triggers userScreenCustomerTypeFieldChanged to be changed so no need to make any further calls
		}
		else 
		{
			//update via apis
			var updatedUserToSave = this.cloneUserToSyncObject( this.zendesk_user_object_to_sync );
			updatedUserToSave.customer_type = this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_ORGANIZATION;
			console.log( "About to save user:");
			console.dir( updatedUserToSave );
			this.ajax( 'updateZendeskUser', updatedUserToSave );
		}

	},

	standardButtonOnClick: function()
	{
		console.log( "started standardButtonOnClick" );
		if( this.currentLocation() == this.resources.APP_LOCATION_USER )
		{
			console.dir(  this.user().customField( this.resources.USER_FIELD_NAME_CUSTOMER_TYPE, this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_DEFAULT ) );
		    //thsi triggers userScreenCustomerTypeFieldChanged to be changed so no need to make any further calls
		}
		else 
		{
			//update via apis
			var updatedUserToSave = this.cloneUserToSyncObject( this.zendesk_user_object_to_sync );
			updatedUserToSave.customer_type = this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_DEFAULT;
			console.log( "About to save user:");
			console.dir( updatedUserToSave );
			this.ajax( 'updateZendeskUser', updatedUserToSave );
		}

	},


	//MAIN SCREEN EVENT FUNCTIONS
    userScreenCustomerTypeFieldChanged: function(evt)
    {
		console.log( "userScreenCustomerTypeFieldChanged called");
		console.log( "event:"); console.dir(evt);

		//fetch new value from field and old value from user
		var oldCustomerType = this.zendesk_user_object_to_sync.customer_type;
		var newCustomerTypeSelected = this.user().customField( this.resources.USER_FIELD_NAME_CUSTOMER_TYPE );
		this.changeCustomerType( oldCustomerType, newCustomerTypeSelected );
    },

    //SWITCH TO HTML TEMPLATE FUNCTIONS
	switchToMainTemplate: function() 
	{
		console.log( "started switchToMainTemplate with the following object:" );
		console.dir( this.zendesk_user_object_to_sync ); console.log( "" );

		var formData = 
		{
		  'user': this.zendesk_user_object_to_sync,
		  'buttons': 
		  {
		  	'exclude': { 'show': true, 'classNameInsert': ( this.zendesk_user_object_to_sync.customer_type == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_EXCLUDE ) ? " active" : "" },
		  	'organization': { 'show': ( this.zendesk_user_object_to_sync.organization != null ), 'classNameInsert': ( this.zendesk_user_object_to_sync.customer_type == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_ORGANIZATION ) ? " active" : "" },
		  	'standard': { 'show': true, 'classNameInsert': ( this.zendesk_user_object_to_sync.customer_type == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_DEFAULT ) ? " active" : "" }
		  },
		  'display_params':
		  {
		  	'customer_type_not_set'		: ( this.zendesk_user_object_to_sync.customer_type == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_NOT_SET ),
		  	'customer_type_exclude'		: ( this.zendesk_user_object_to_sync.customer_type == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_EXCLUDE ),
		  	'customer_type_included'	: ( this.zendesk_user_object_to_sync.customer_type == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_ORGANIZATION || this.zendesk_user_object_to_sync.customer_type == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_DEFAULT ),
		  	'customer_type_organization': ( this.zendesk_user_object_to_sync.customer_type == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_ORGANIZATION),
		  	'customer_type_stabdard'	: ( this.zendesk_user_object_to_sync.customer_type == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_DEFAULT )
		  }
		};

		console.log( "switching to form with object:" );
		console.dir( formData ); console.log( "" );

	    this.switchTo( this.resources.TEMPLATE_NAME_MAIN, formData );
	},
/*
	switchToSyncDataTable: function() 
	{

		console.log( "started switchToSyncDataTable" );
		//console.log( zendeskUserObject )

		var requester_data = {
		  'ticket_requester': 'requesterUserId',
		  'name': this.zendesk_user_object_to_sync.name,
		  'tags': this.zendesk_user_object_to_sync.organizations,
		  'created_at': this.zendesk_user_object_to_sync.external_subscriber_id,
		  'last_login_at': 'test'
		};
		console.dir( requester_data );
	    this.switchTo( 'sync_user_details', requester_data );
	},
*/
	switchToErrorMessage: function( errorResponse ) {
		console.log( "started switchToErrorMessage with the folloring object:" );
		console.dir( errorResponse ); console.log( "" );
		this.switchTo( 'show_error', errorResponse );
	}

  };

}());









