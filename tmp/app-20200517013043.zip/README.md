# John's bespoke Zendesk Plugin to Sync Contacts with Mailchimp without having to buy the commercial plugin

Just install and configure to map the zendesk fields to the mailchimo fields and you will have a fully incorporated fuly functional additional section on your zendesk ticket screen and contact screen to seamlessly allow you to push contact data from Zendesk to Mailchimp.

It works really well and I used it commercially for years! and it's free - unlike the commercial one on the Zendesk app store.

Please submit bug reports to [john@upnrunning.co.uk](). Pull requests are welcome.
