(function() {

console.log("Loading app.js");

  return {

    defaultState: 'loading_screen',

    resources: {
      APP_LOCATION_TICKET: "ticket_sidebar",
      APP_LOCATION_USER: "user_sidebar",

      USER_FIELD_NAME_EXTERNAL_ID: "mailshot_external_subscriberid",
      USER_FIELD_NAME_CUSTOMER_TYPE: "mailshot_customer_type",
      USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_NOT_SET: null,
      USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_EXCLUDE: "mailshot_exclude_from_mailshot",
      USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_DEFAULT: "mailshot_use_default_values",
      USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_ORGANIZATION: "mailshot_use_organisation_values",

      TEMPLATE_UNCONFIGURED_USER_CONFIG: "unconfigured_user_config",

      DATE_PATTERN : /^\d{4}-\d{2}-\d{2}$/
    },

    requests: 
    {
    	getZendeskUser: function(id)
    	{
    		var userApiCallSettings = 
    		{
				url: helpers.fmt('/api/v2/users/%@.json', id),
				type:'GET',
				dataType: 'json'
			};
			console.log( "API CAll DETAILS FOR getZendeskUser;" );
			console.dir( userApiCallSettings ); console.log();
        	return userApiCallSettings;
		},

		getMailChimpListMember: function( subscriberId )
		{
			var jsonCall =
			{
				url: helpers.fmt( "https://%@.api.mailchimp.com/2.0/lists/member-info.json", this.mailchimp_datacentre_prefix ),
				type: 'POST',
				dataType: 'json',
				contentType: 'application/json; charset=UTF-8',
				data: JSON.stringify(
				{
					"apikey": this.mailchimp_api_key,
					"id": this.mailchimp_list_id,
				    "emails": [
				        {
				            "email": null,
				            "euid": null,
				            "leid": subscriberId
				        }
				    ]
				})
			};
			console.log( "API CAll DETAILS FOR getMailChimpListMember;" );
			console.dir( jsonCall ); console.log();
			return jsonCall;
		},

		getMailChimpAllListMembers: function( subscriberId )
		{
			var jsonCall =
			{
				//url: "https://us13.api.mailchimp.com/2.0/lists/members",
				url: helpers.fmt( "https://%@.api.mailchimp.com/2.0/lists/members.json", this.mailchimp_datacentre_prefix ),
				type: 'POST',
				dataType: 'json',
				contentType: 'application/json; charset=UTF-8',
				data: JSON.stringify(
				{
					"apikey": this.mailchimp_api_key,
					"id": this.mailchimp_list_id,
					"status": "subscribed",
					"opts": {
					    "start": 0,
					    "limit": 100,
					    "sort_field": "email",
					    "sort_dir": "ASC"
					}
				})
			};
			console.log( "API CAll DETAILS FOR getMailChimpAllListMembers;" );
			console.dir( jsonCall ); console.log();
			return jsonCall;
		}

	},


    events: {
      'app.activated'                : 'init',

      // Requests
      'getZendeskUser.done': 'gotUserFromDataAPI',
      'getZendeskUser.fail': 'switchToErrorMessage',
      'getMailChimpListMember.done': 'retrievedMailchimpSubscriber',
      'getMailChimpListMember.fail': 'switchToErrorMessage'       

      //'click .get_no_auth'           : 'getNoAuth',
      //'click .get_with_auth'         : 'getWithAuth',
      //'click .post_with_auth'        : 'openEditUserForm',
      //'click .put_with_auth'         : 'putWithAuth',
      //'fetchHeartyQuotes.done'       : 'renderHeartyQuote',
      //'fetchTeachMyAPIUsers.done'    : 'renderUserList',
      //'postTeachMyAPIUsers.done'     : 'postCleanup',
      //'fetchTeachMyAPIUserById.done' : 'openUpdateUserForm',
      //'putTeachMyAPIUserById.done'   : 'putCleanup',
      //'postTeachMyAPIUsers.fail'     : 'fail',
      //'fetchTeachMyAPIUsers.fail'    : 'fail',
      //'fetchTeachMyAPIUserById.fail' : 'fail',
      //'putTeachMyAPIUserById.fail'   : 'fail',
      //'click .back_to_start'         : 'renderStartPage',
      //'click .update'                : 'getUserInfo',
      //'click .modal_close'           : 'closeModal',
      //'hidden .my_modal'             : 'renderStartPage',
      //'click .btn_submit'            : 'createUser',
      //'click .btn_update'            : 'updateUser'
    },

    init: function() 
    {
    	console.log( "Starting init");
    	console.log( "Location Object:" );
    	console.dir( this.currentLocation() );
    	console.log( "This =" );
		console.dir( this );
        
        //Get Settings from manifest.js
		this.mailchimp_api_key = this.setting('mailchimp_api_key');
		this.mailchimp_datacentre_prefix = this.setting('mailchimp_datacentre_prefix');
		this.mailchimp_list_id = this.setting('mailchimp_list_id');

		//fetch current user object and use it to store gloabl user variables for use later
		this.zendesk_user_object_to_sync = null;
		if( this.currentLocation() == this.resources.APP_LOCATION_TICKET )
		{
			this.ajax( 'getZendeskUser', this.ticket().requester().id() );
		}
		else if( this.currentLocation() == this.resources.APP_LOCATION_USER )
		{
			this.getUserFromFrameworkInUserSidebarLocation();
		}
    },

    getUserFromFrameworkInUserSidebarLocation: function()
    {
		console.log( 'Starting getUserFromFrameworkInUserSidebarLocation' );
		console.log( 'this.user() object from framework = ' );
		console.dir( this.user() );
		console.log( 'this.userFields() object from framework = ' );
		console.dir( this.userFields() );
		console.log( 'this.user().organizations() object from framework = ' );
		console.dir( this.user().organizations() );
		console.log( 'this.user().organizations()[0] object from framework = ' );
		console.dir( this.user().organizations()[0] );

		this.zendesk_user_object_to_sync = 
		{
			id: this.user().id(),
			name: this.user().name(),
			email: this.user().email(),
			organization: ( typeof( this.user().organizations()[0] ) == 'undefined' ) ? null : { id: this.user().organizations()[0].id(), name: this.user().organizations()[0].name() },
			customer_type: this.user().customField( this.resources.USER_FIELD_NAME_CUSTOMER_TYPE ),
			external_subscriber_id: this.user().customField( this.resources.USER_FIELD_NAME_EXTERNAL_ID )
		};
		this.userDataInitialized();
    },

	gotUserFromDataAPI: function( userObjectFromDataAPI )
	{
		console.log( 'Starting gotUserFromDataAPI' );
		console.log( 'user object from API = ' );
		console.dir( userObjectFromDataAPI );


		if( this.zendesk_user_object_to_sync == null && userObjectFromDataAPI != null )
		{
			this.zendesk_user_object_to_sync = 
			{
				id: userObjectFromDataAPI.user.id,
				name: userObjectFromDataAPI.user.name,
				email: userObjectFromDataAPI.user.email,
				//ORG_ID: userObjectFromDataAPI.user.organization_id,
				organization: ( userObjectFromDataAPI.user.organization_id == null ) ? null : { id: userObjectFromDataAPI.user.organization_id, name: null },
				customer_type: userObjectFromDataAPI.user.user_fields.mailshot_customer_type,
				external_subscriber_id: userObjectFromDataAPI.user.user_fields.mailshot_external_subscriberid
			};
			this.userDataInitialized();
		}
		else console.warn( "gotUserFromDataAPI called but this.zendesk_user_object_to_sync != null or userObjectFromDataAPI = null - this should never happen!");
	},

	userDataInitialized: function()
	{
		if( this.zendesk_user_object_to_sync != null )
		{
			console.log( 'user object = ' );
			console.dir( this.zendesk_user_object_to_sync );

			//user is definitely initialised so lets see if they are new and havent been configured for mailshot settings yet
			if( this.zendesk_user_object_to_sync.customer_type == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_NOT_SET )
			{
				this.switchToUserNotSetupOptions();
			}
			else
			{
				this.ajax( 'getMailChimpListMember', this.zendesk_user_object_to_sync.external_subscriber_id );
			}
		}
		else console.warn( "userDataInitialized called but this.zendesk_user_object_to_sync = null - this should never happen!");
	},  
    
	retrievedMailchimpSubscriber: function( mailchimpSubscriber ) 
	{

		console.log( "started retrievedMailchimpSubscriber with the following object:" );
		console.dir( mailchimpSubscriber ); console.log( "" );
		this.switchToSyncDataTable();
	},

	switchToUserNotSetupOptions: function() 
	{
		console.log( "started switchToUserNotSetupOptions with the following object:" );
		console.dir( this.zendesk_user_object_to_sync ); console.log( "" );

		var formData = 
		{
		  'user': this.zendesk_user_object_to_sync,
		  'buttons': 
		  {
		  	'exclude': { 'show': true, 'classNameInsert': ( this.zendesk_user_object_to_sync.customer_type == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_EXCLUDE ) ? " active" : "" },
		  	'organization': { 'show': ( this.zendesk_user_object_to_sync.organization != null ), 'classNameInsert': ( this.zendesk_user_object_to_sync.customer_type == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_ORGANIZATION ) ? " active" : "" },
		  	'standard': { 'show': true, 'classNameInsert': ( this.zendesk_user_object_to_sync.customer_type == this.resources.USER_FIELD_NAME_CUSTOMER_TYPE_VALUE_USE_DEFAULT ) ? " active" : "" }
		  }
		};

		console.log( "switching to form with object:" );
		console.dir( formData ); console.log( "" );

	    this.switchTo( this.resources.TEMPLATE_UNCONFIGURED_USER_CONFIG, formData );
	},

	switchToSyncDataTable: function() 
	{

		console.log( "started switchToSyncDataTable" );
		//console.log( zendeskUserObject )

		var requester_data = {
		  'ticket_requester': 'requesterUserId',
		  'name': this.zendesk_user_object_to_sync.name,
		  'tags': this.zendesk_user_object_to_sync.organizations,
		  'created_at': this.zendesk_user_object_to_sync.external_subscriber_id,
		  'last_login_at': 'test'
		};
		console.dir( requester_data );
	    this.switchTo( 'sync_user_details', requester_data );
	},

	switchToErrorMessage: function( errorResponse ) {
		console.log( "started switchToErrorMessage with the folloring object:" );
		console.dir( errorResponse ); console.log( "" );
		this.switchTo( 'show_error', errorResponse );
	}

  };

}());



